# INNOPOLIS_2

Домашнее задание по блоку 2.

4 файла
homework_2_1.ipynb - задание 1
homework_2_2.ipynb - задание 2
homework_2_3.ipynb - задание 3
homework_2.ipynb - все 3 задания в одном файле
